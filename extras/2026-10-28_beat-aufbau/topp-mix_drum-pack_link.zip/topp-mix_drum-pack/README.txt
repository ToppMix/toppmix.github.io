TOPP MIX DRUM-PACK
Gratis-Extra zum Video "Wie ist ein Beat aufgebaut?"

Inhalt
------
- midi/Trap 140 BPM Teil 1/  (Trap Teil 1, 140 BPM): gesamt.mid, kick.mid, snare.mid, clap.mid, hihat.mid, open-hihat.mid
- midi/Trap 140 BPM Teil 2/  (Trap Teil 2, 140 BPM): gesamt.mid, kick.mid, snare.mid, clap.mid, hihat.mid, open-hihat.mid
- midi/Drill 140 BPM Teil 1/  (Drill Teil 1, 140 BPM): gesamt.mid, kick.mid, snare.mid, hihat.mid
- midi/Drill 140 BPM Teil 2/  (Drill Teil 2, 140 BPM): gesamt.mid, kick.mid, snare.mid, hihat.mid, open-hihat.mid
- midi/Boom Bap 90 BPM Teil 1/  (Boom Bap Teil 1, 90 BPM, Swing): gesamt.mid, kick.mid, snare.mid, hihat.mid, open-hihat.mid
- midi/Boom Bap 88 BPM Teil 2/  (Boom Bap Teil 2, 88 BPM, Swing): gesamt.mid, kick.mid, snare.mid, hihat.mid
- topp-mix_drum-pack_link.pdf  (Erklärung, Raster, Tipps)

Pro Pattern ein Ordner (Richtung, Tempo, Teil im Namen) mit:
- gesamt.mid  = alle Spuren, General-MIDI-Belegung (Kick 36, Snare 38, Clap 39, Closed Hi-Hat 42, Open Hi-Hat 46)
- kick.mid, snare.mid, hihat.mid (und clap.mid, open-hihat.mid, falls vorhanden) = je eine Spur, alle Noten auf einer Tonhöhe (C5)
Alle Dateien: 4 Takte, 4/4, loopfähig, gleiches Tempo, gleiche Länge.

So geht's
---------
Am PC entpacken. Einzelspuren (kick.mid usw.) in je einen Sampler-Kanal ziehen, Sample laden und die Spur passend zuweisen.
gesamt.mid für Drum-Maschinen oder Drum-Plugins mit General-MIDI-Belegung.
Klingt ein Sample verstimmt, stelle die Tonhöhe des Kanals nach.
MIDI-Dateien lassen sich am Handy kaum nutzen, öffne das Pack am PC.

Lizenz
------
Frei nutzbar in deinen eigenen Beats und Songs.
Nicht als Pack oder als einzelne Dateien weiterverkaufen oder weitergeben.

Topp Mix – Beats, Mix & Mastering: [LINK]
