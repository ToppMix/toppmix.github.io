TOPP MIX TONLEITER-POSTER
Gratis-Extra zum Video "Tonleitern kurz erklärt"

Inhalt
------
- topp-mix_tonleiter-poster_link.pdf

Alle 12 Moll- und 12 Dur-Tonleitern mit deutschen Notennamen und dem Ganz-/Halbton-Muster.

Alle Gratis-Extras: [LINK]
