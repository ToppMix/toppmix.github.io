TOPP MIX AKKORD-SPICKZETTEL
Gratis-Extra zum Video "Eine gute Melodie bauen"

Inhalt
------
- topp-mix_akkord-spickzettel_link.pdf
- melodie_am-f.mid

Akkorde in A-Moll, Progressionen für Trap und Drill und die Melodie aus dem Video als MIDI.

Alle Gratis-Extras: [LINK]
