TOPP MIX EQ-SPICKZETTEL
Gratis-Extra zum Video "Was macht ein Equalizer?"

Inhalt
------
- topp-mix_eq-spickzettel_instagram.pdf

Frequenzbereiche, Startwerte je Spur, Vorgehen und typische Fehler beim EQ.

Alle Gratis-Extras: [LINK]
